from typing import Any

from psycopg2.extensions import connection


def add_job_event(
    conn: connection,
    job_id: int,
    message: str,
    level: str = "INFO",
    event_type: str = "general",
    ioc_id: int | None = None,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            INSERT INTO enrichment_job_events (
                job_id,
                level,
                event_type,
                message,
                ioc_id
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s
            )
            """,
            (
                job_id,
                level.upper(),
                event_type,
                message,
                ioc_id,
            ),
        )


def claim_pending_job(
    conn: connection,
    provider: str = "virustotal",
) -> dict[str, Any] | None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                id,
                provider,
                total_items,
                rate_limit_per_minute,
                max_attempts
            FROM enrichment_jobs
            WHERE provider = %s
              AND status = 'pending'
            ORDER BY created_at
            LIMIT 1
            FOR UPDATE SKIP LOCKED
            """,
            (provider,),
        )

        row = cursor.fetchone()

        if row is None:
            return None

        (
            job_id,
            job_provider,
            total_items,
            rate_limit,
            max_attempts,
        ) = row

        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'running',
                started_at = COALESCE(
                    started_at,
                    CURRENT_TIMESTAMP
                ),
                completed_at = NULL,
                error = NULL,
                pause_requested = FALSE,
                cancel_requested = FALSE,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )

        add_job_event(
            conn=conn,
            job_id=job_id,
            level="INFO",
            event_type="job_started",
            message=(
                "Iniciando trabajo de VirusTotal "
                f"ID: {job_id}"
            ),
        )

        return {
            "id": job_id,
            "provider": job_provider,
            "total_items": total_items,
            "rate_limit_per_minute": rate_limit,
            "max_attempts": max_attempts,
        }


def get_job_control(
    conn: connection,
    job_id: int,
) -> dict[str, bool] | None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                pause_requested,
                cancel_requested
            FROM enrichment_jobs
            WHERE id = %s
            """,
            (job_id,),
        )

        row = cursor.fetchone()

        if row is None:
            return None

        return {
            "pause_requested": bool(row[0]),
            "cancel_requested": bool(row[1]),
        }


def mark_job_paused(
    conn: connection,
    job_id: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'paused',
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )

    add_job_event(
        conn=conn,
        job_id=job_id,
        level="WARN",
        event_type="job_paused",
        message="El análisis fue pausado.",
    )


def wait_for_resume_or_cancel(
    conn: connection,
    job_id: int,
) -> str:
    control = get_job_control(
        conn=conn,
        job_id=job_id,
    )

    if control is None:
        return "cancel"

    if control["cancel_requested"]:
        return "cancel"

    if control["pause_requested"]:
        return "pause"

    return "continue"


def mark_job_running(
    conn: connection,
    job_id: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'running',
                pause_requested = FALSE,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )

    add_job_event(
        conn=conn,
        job_id=job_id,
        level="INFO",
        event_type="job_resumed",
        message="El análisis fue reanudado.",
    )


def set_current_ioc(
    conn: connection,
    job_id: int,
    ioc_id: int,
    ioc_type: str,
    value: str,
    source: str | None,
    attempt: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                current_ioc_id = %s,
                current_ioc_type = %s,
                current_ioc_value = %s,
                current_ioc_source = %s,
                current_attempt = %s,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                ioc_id,
                ioc_type,
                value,
                source,
                attempt,
                job_id,
            ),
        )


def clear_current_ioc(
    conn: connection,
    job_id: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                current_ioc_id = NULL,
                current_ioc_type = NULL,
                current_ioc_value = NULL,
                current_ioc_source = NULL,
                current_attempt = 0,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )


def create_job_baseline(
    conn: connection,
    job_id: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                COUNT(*) FILTER (
                    WHERE vt_estado = 'analizado'
                ),
                COUNT(*) FILTER (
                    WHERE vt_estado = 'error'
                )
            FROM iocs
            """
        )

        analyzed, errors = cursor.fetchone()

        cursor.execute(
            """
            INSERT INTO enrichment_job_baselines (
                job_id,
                analyzed_at_start,
                errors_at_start
            )
            VALUES (
                %s,
                %s,
                %s
            )
            ON CONFLICT (job_id) DO NOTHING
            """,
            (
                job_id,
                analyzed,
                errors,
            ),
        )


def update_job_progress(
    conn: connection,
    job_id: int,
) -> dict[str, int]:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                analyzed_at_start,
                errors_at_start
            FROM enrichment_job_baselines
            WHERE job_id = %s
            """,
            (job_id,),
        )

        baseline = cursor.fetchone()

        if baseline is None:
            analyzed_at_start = 0
            errors_at_start = 0
        else:
            analyzed_at_start, errors_at_start = baseline

        cursor.execute(
            """
            SELECT
                COUNT(*) FILTER (
                    WHERE vt_estado = 'analizado'
                ),
                COUNT(*) FILTER (
                    WHERE vt_estado = 'error'
                )
            FROM iocs
            """
        )

        analyzed, errors = cursor.fetchone()

        successful = max(
            analyzed - analyzed_at_start,
            0,
        )

        failed = max(
            errors - errors_at_start,
            0,
        )

        processed = successful + failed

        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                processed_items = %s,
                successful_items = %s,
                failed_items = %s,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                processed,
                successful,
                failed,
                job_id,
            ),
        )

        return {
            "processed": processed,
            "successful": successful,
            "failed": failed,
        }


def complete_job(
    conn: connection,
    job_id: int,
) -> None:
    progress = update_job_progress(
        conn=conn,
        job_id=job_id,
    )

    clear_current_ioc(
        conn=conn,
        job_id=job_id,
    )

    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'completed',
                completed_at = CURRENT_TIMESTAMP,
                pause_requested = FALSE,
                cancel_requested = FALSE,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )

    add_job_event(
        conn=conn,
        job_id=job_id,
        level="INFO",
        event_type="job_completed",
        message=(
            "Trabajo completado. "
            f"Procesados: {progress['processed']}, "
            f"exitosos: {progress['successful']}, "
            f"errores: {progress['failed']}."
        ),
    )


def cancel_job(
    conn: connection,
    job_id: int,
) -> None:
    update_job_progress(
        conn=conn,
        job_id=job_id,
    )

    clear_current_ioc(
        conn=conn,
        job_id=job_id,
    )

    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'cancelled',
                completed_at = CURRENT_TIMESTAMP,
                pause_requested = FALSE,
                cancel_requested = TRUE,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (job_id,),
        )

    add_job_event(
        conn=conn,
        job_id=job_id,
        level="WARN",
        event_type="job_cancelled",
        message="El análisis fue cancelado.",
    )


def fail_job(
    conn: connection,
    job_id: int,
    error: str,
) -> None:
    clear_current_ioc(
        conn=conn,
        job_id=job_id,
    )

    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE enrichment_jobs
            SET
                status = 'failed',
                completed_at = CURRENT_TIMESTAMP,
                error = %s,
                last_activity_at = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                error[:2000],
                job_id,
            ),
        )

    add_job_event(
        conn=conn,
        job_id=job_id,
        level="ERROR",
        event_type="job_failed",
        message=f"El trabajo falló: {error}",
    )
