from typing import Any

from psycopg2.extensions import connection


def get_pending_iocs(
    conn: connection,
    limit: int,
    max_retries: int,
) -> list[tuple]:
    """
    Obtiene IOC pendientes elegibles para VirusTotal.

    Retorna:
        id,
        analysis_id,
        tipo,
        valor,
        retry_count,
        fuente
    """

    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                id,
                analysis_id,
                tipo,
                valor,
                COALESCE(vt_retry_count, 0),
                fuente
            FROM iocs
            WHERE vt_estado = 'pendiente'
              AND COALESCE(vt_retry_count, 0) < %s
            ORDER BY id
            LIMIT %s
            FOR UPDATE SKIP LOCKED
            """,
            (
                max_retries,
                limit,
            ),
        )

        return cursor.fetchall()


def mark_analyzed(
    conn: connection,
    ioc_id: int,
    stats: dict[str, Any],
) -> None:
    malicious = int(
        stats.get("malicious", 0) or 0
    )
    suspicious = int(
        stats.get("suspicious", 0) or 0
    )
    harmless = int(
        stats.get("harmless", 0) or 0
    )
    undetected = int(
        stats.get("undetected", 0) or 0
    )

    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE iocs
            SET
                vt_malicious = %s,
                vt_suspicious = %s,
                vt_harmless = %s,
                vt_undetected = %s,
                vt_score = %s,
                proveedor_reputacion = 'VirusTotal',
                vt_estado = 'analizado',
                vt_http_code = 200,
                vt_error = NULL,
                ultima_consulta = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                malicious,
                suspicious,
                harmless,
                undetected,
                malicious,
                ioc_id,
            ),
        )


def mark_error(
    conn: connection,
    ioc_id: int,
    status_code: int | None,
    error: str,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE iocs
            SET
                vt_estado = 'error',
                vt_http_code = %s,
                vt_error = %s,
                ultima_consulta = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                status_code,
                error[:1000],
                ioc_id,
            ),
        )


def increment_retry(
    conn: connection,
    ioc_id: int,
    status_code: int | None,
    error: str,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            UPDATE iocs
            SET
                vt_retry_count =
                    COALESCE(vt_retry_count, 0) + 1,
                vt_http_code = %s,
                vt_error = %s,
                ultima_consulta = CURRENT_TIMESTAMP
            WHERE id = %s
            """,
            (
                status_code,
                error[:1000],
                ioc_id,
            ),
        )


def get_ioc_result(
    conn: connection,
    ioc_id: int,
) -> dict | None:
    with conn.cursor() as cursor:
        cursor.execute(
            """
            SELECT
                vt_estado,
                COALESCE(vt_malicious, 0),
                COALESCE(vt_suspicious, 0),
                COALESCE(vt_harmless, 0),
                COALESCE(vt_undetected, 0),
                vt_http_code,
                vt_error,
                COALESCE(vt_retry_count, 0)
            FROM iocs
            WHERE id = %s
            """,
            (ioc_id,),
        )

        row = cursor.fetchone()

    if row is None:
        return None

    return {
        "estado": row[0],
        "malicious": row[1],
        "suspicious": row[2],
        "harmless": row[3],
        "undetected": row[4],
        "http_code": row[5],
        "error": row[6],
        "retry_count": row[7],
    }
