let statusTimer = null;
let eventsTimer = null;
let lastEventId = 0;
let activeJobId = null;
let totalRenderedEvents = 0;


function element(id) {
    return document.getElementById(id);
}


function setText(id, value) {
    const target = element(id);

    if (target) {
        target.textContent =
            value ?? "—";
    }
}


function formatNumber(value) {
    return Number(
        value ?? 0
    ).toLocaleString("es-MX");
}


function formatDuration(seconds) {
    const safeSeconds = Math.max(
        Number(seconds ?? 0),
        0
    );

    const hours = Math.floor(
        safeSeconds / 3600
    );

    const minutes = Math.floor(
        (safeSeconds % 3600) / 60
    );

    const remainingSeconds = Math.floor(
        safeSeconds % 60
    );

    return [
        hours,
        minutes,
        remainingSeconds
    ]
        .map(
            value => String(value).padStart(2, "0")
        )
        .join(":");
}


function formatDate(value) {
    if (!value) {
        return "—";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "—";
    }

    return date.toLocaleString(
        "es-MX",
        {
            dateStyle: "short",
            timeStyle: "medium"
        }
    );
}


function formatTime(value) {
    if (!value) {
        return "--:--:--";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "--:--:--";
    }

    return date.toLocaleTimeString(
        "es-MX",
        {
            hour12: false
        }
    );
}


function showMessage(
    message,
    type = "info"
) {
    const target =
        element("vt-control-message");

    if (!target) {
        return;
    }

    target.hidden = false;
    target.textContent = message;
    target.dataset.type = type;
}


function updateControlButtons(status) {
    const start = element(
        "start-virustotal-analysis"
    );

    const pause = element(
        "pause-virustotal-analysis"
    );

    const resume = element(
        "resume-virustotal-analysis"
    );

    const cancel = element(
        "cancel-virustotal-analysis"
    );

    const retry = element(
        "retry-virustotal-errors"
    );

    const isActive = [
        "pending",
        "running",
        "paused"
    ].includes(status);

    if (start) {
        start.disabled = isActive;
    }

    if (pause) {
        pause.disabled =
            status !== "running";
    }

    if (resume) {
        resume.disabled =
            status !== "paused";
    }

    if (cancel) {
        cancel.disabled =
            !isActive;
    }

    if (retry) {
        retry.disabled =
            isActive;
    }
}


function updateCurrentItem(data) {
    const item = data.current_item ?? {};

    const hasCurrentItem =
        Boolean(item.id || item.valor);

    setText(
        "vt-current-value",
        hasCurrentItem
            ? item.valor
            : "Ningún IOC en proceso"
    );

    setText(
        "vt-current-type",
        item.tipo ?? "—"
    );

    setText(
        "vt-current-type-badge",
        item.tipo?.toUpperCase() ?? "—"
    );

    setText(
        "vt-current-source",
        `Fuente: ${item.fuente ?? "—"}`
    );

    setText(
        "vt-current-attempt",
        `${item.attempt ?? 0} / ` +
        `${item.max_attempts ?? 3}`
    );

    setText(
        "vt-current-id",
        item.id ?? "—"
    );

    setText(
        "vt-last-activity",
        formatDate(data.last_activity_at)
    );

    setText(
        "vt-current-state",
        hasCurrentItem
            ? "Procesando"
            : (
                data.status === "running"
                    ? "Esperando siguiente IOC"
                    : "En espera"
            )
    );
}


function updateProgress(data) {
    const total =
        Number(data.total_items ?? 0);

    const processed =
        Number(data.processed_items ?? 0);

    const percentage =
        Number(data.percentage ?? 0);

    const summary = data.summary ?? {};

    setText(
        "vt-pending-count",
        formatNumber(summary.pending)
    );

    setText(
        "vt-analyzed-count",
        formatNumber(summary.analyzed)
    );

    setText(
        "vt-errors-count",
        formatNumber(summary.errors)
    );

    setText(
        "vt-total-count",
        formatNumber(total)
    );

    setText(
        "vt-progress-percentage",
        `${percentage.toFixed(2)}%`
    );

    setText(
        "vt-progress-text",
        `${formatNumber(processed)} de ` +
        `${formatNumber(total)} procesados`
    );

    setText(
        "vt-progress-title",
        data.status === "running"
            ? (
                `Procesando IOC ${Math.min(
                    processed + 1,
                    total
                )} de ${total}`
            )
            : (
                data.status === "paused"
                    ? "Análisis pausado"
                    : "Estado del análisis"
            )
    );

    const progressBar =
        element("vt-progress-bar");

    if (progressBar) {
        progressBar.style.width =
            `${Math.min(percentage, 100)}%`;
    }

    setText(
        "vt-provider",
        data.provider ?? "VirusTotal"
    );

    setText(
        "vt-rate-limit",
        `${data.rate_limit_per_minute ?? 4} IOC/min`
    );

    setText(
        "vt-elapsed",
        formatDuration(data.elapsed_seconds)
    );

    setText(
        "vt-remaining-time",
        formatDuration(
            data.estimated_remaining_seconds
        )
    );

    setText(
        "vt-started-at",
        formatDate(data.started_at)
    );

    setText(
        "vt-job-id",
        data.id ?? "—"
    );

    setText(
        "vt-estimated-finish",
        data.estimated_remaining_seconds > 0
            ? (
                "Tiempo restante estimado: " +
                formatDuration(
                    data.estimated_remaining_seconds
                )
            )
            : "Finalización estimada: —"
    );

    setText(
        "vt-summary-status",
        String(
            data.status ?? "idle"
        ).toUpperCase()
    );

    setText(
        "vt-summary-progress",
        `${formatNumber(processed)} / ` +
        `${formatNumber(total)}`
    );

    setText(
        "vt-summary-percentage",
        `${percentage.toFixed(2)}%`
    );

    setText(
        "vt-success-count",
        formatNumber(data.successful_items)
    );

    setText(
        "vt-failed-count",
        formatNumber(data.failed_items)
    );

    const statusBadge =
        element("vt-job-status");

    if (statusBadge) {
        statusBadge.textContent =
            String(
                data.status ?? "idle"
            ).toUpperCase();

        statusBadge.dataset.status =
            data.status ?? "idle";
    }

    updateCurrentItem(data);
    updateControlButtons(data.status);

    if (
        activeJobId !== null &&
        data.id !== activeJobId
    ) {
        resetConsole();
    }

    activeJobId = data.id ?? null;
}


async function apiRequest(
    url,
    options = {}
) {
    const response = await fetch(
        url,
        {
            cache: "no-store",
            ...options
        }
    );

    const payload = await response.json();

    if (!response.ok) {
        throw new Error(
            payload.detail ??
            payload.message ??
            `HTTP ${response.status}`
        );
    }

    return payload;
}


async function loadVirusTotalStatus() {
    try {
        const data = await apiRequest(
            "/api/enrichment/virustotal/status"
        );

        updateProgress(data);

        setText(
            "vt-console-connection",
            "Conectado"
        );

    } catch (error) {
        console.error(error);

        setText(
            "vt-console-connection",
            "Sin conexión"
        );

        showMessage(
            "No fue posible consultar el estado.",
            "error"
        );
    }
}


function appendConsoleEvent(event) {
    const consoleElement =
        element("vt-live-console");

    if (!consoleElement) {
        return;
    }

    const empty =
        consoleElement.querySelector(
            ".ec-console-empty"
        );

    if (empty) {
        empty.remove();
    }

    const line = document.createElement("div");
    line.className = "ec-console-line";
    line.dataset.level =
        event.level ?? "INFO";

    const time = document.createElement("span");
    time.className = "ec-console-time";
    time.textContent =
        `[${formatTime(event.created_at)}]`;

    const level = document.createElement("span");
    level.className = "ec-console-level";
    level.textContent =
        event.level ?? "INFO";

    const message = document.createElement("span");
    message.className = "ec-console-message";
    message.textContent =
        event.message ?? "";

    line.append(
        time,
        level,
        message
    );

    consoleElement.appendChild(line);

    const maximumConsoleLines = 300;

    while (
        consoleElement.children.length >
        maximumConsoleLines
    ) {
        consoleElement.removeChild(
            consoleElement.firstElementChild
        );
    }

    totalRenderedEvents += 1;

    setText(
        "vt-event-count",
        formatNumber(totalRenderedEvents)
    );

    const autoscroll =
        element("vt-console-autoscroll");

    if (autoscroll?.checked) {
        consoleElement.scrollTop =
            consoleElement.scrollHeight;
    }
}


async function loadVirusTotalEvents() {
    try {
        const data = await apiRequest(
            (
                "/api/enrichment/virustotal/events" +
                `?after_id=${lastEventId}` +
                "&limit=200"
            )
        );

        if (
            activeJobId !== null &&
            data.job_id !== activeJobId
        ) {
            resetConsole();
        }

        activeJobId =
            data.job_id ?? activeJobId;

        for (const event of data.events ?? []) {
            appendConsoleEvent(event);
        }

        lastEventId =
            Number(
                data.last_event_id ??
                lastEventId
            );

    } catch (error) {
        console.error(
            "Error obteniendo eventos:",
            error
        );
    }
}


async function executeControlAction(
    endpoint,
    successType = "success"
) {
    try {
        const data = await apiRequest(
            endpoint,
            {
                method: "POST"
            }
        );

        showMessage(
            data.message,
            successType
        );

        await Promise.all([
            loadVirusTotalStatus(),
            loadVirusTotalEvents()
        ]);

    } catch (error) {
        console.error(error);

        showMessage(
            error.message,
            "error"
        );
    }
}


async function startVirusTotalAnalysis() {
    await executeControlAction(
        "/api/enrichment/virustotal/start"
    );

    startPolling();
}


async function pauseVirusTotalAnalysis() {
    await executeControlAction(
        "/api/enrichment/virustotal/pause",
        "info"
    );
}


async function resumeVirusTotalAnalysis() {
    await executeControlAction(
        "/api/enrichment/virustotal/resume"
    );
}


async function cancelVirusTotalAnalysis() {
    const confirmed = window.confirm(
        "¿Cancelar el análisis actual? " +
        "Los IOC pendientes permanecerán sin analizar."
    );

    if (!confirmed) {
        return;
    }

    await executeControlAction(
        "/api/enrichment/virustotal/cancel",
        "info"
    );
}


async function retryVirusTotalErrors() {
    await executeControlAction(
        "/api/enrichment/virustotal/retry-errors"
    );
}


function resetConsole() {
    const consoleElement =
        element("vt-live-console");

    if (consoleElement) {
        consoleElement.innerHTML = `
            <div class="ec-console-empty">
                Esperando eventos del collector...
            </div>
        `;
    }

    lastEventId = 0;
    totalRenderedEvents = 0;

    setText("vt-event-count", "0");
}


function isEnrichmentViewVisible() {
    return (
        window.location.hash === "#/uploads" &&
        Boolean(element("vt-live-console")) &&
        Boolean(element("vt-job-status"))
    );
}


let pollingActive = false;
let statusRequestInProgress = false;
let eventsRequestInProgress = false;


async function pollStatusSafely() {
    if (
        !pollingActive ||
        !isEnrichmentViewVisible() ||
        statusRequestInProgress
    ) {
        return;
    }

    statusRequestInProgress = true;

    try {
        await loadVirusTotalStatus();
    } finally {
        statusRequestInProgress = false;
    }
}


async function pollEventsSafely() {
    if (
        !pollingActive ||
        !isEnrichmentViewVisible() ||
        eventsRequestInProgress
    ) {
        return;
    }

    eventsRequestInProgress = true;

    try {
        await loadVirusTotalEvents();
    } finally {
        eventsRequestInProgress = false;
    }
}


function startPolling() {
    if (
        pollingActive ||
        !isEnrichmentViewVisible()
    ) {
        return;
    }

    pollingActive = true;

    pollStatusSafely();
    pollEventsSafely();

    statusTimer = window.setInterval(
        pollStatusSafely,
        5000
    );

    eventsTimer = window.setInterval(
        pollEventsSafely,
        3000
    );

    console.log(
        "Polling de enriquecimiento iniciado."
    );
}


function stopPolling() {
    pollingActive = false;

    if (statusTimer !== null) {
        window.clearInterval(statusTimer);
        statusTimer = null;
    }

    if (eventsTimer !== null) {
        window.clearInterval(eventsTimer);
        eventsTimer = null;
    }

    statusRequestInProgress = false;
    eventsRequestInProgress = false;

    console.log(
        "Polling de enriquecimiento detenido."
    );
}


function synchronizePollingWithRoute() {
    window.setTimeout(
        () => {
            if (isEnrichmentViewVisible()) {
                startPolling();
            } else {
                stopPolling();
            }
        },
        100
    );
}


function configureControls() {
    document.addEventListener(
        "click",
        event => {
            if (
                event.target.closest(
                    "#start-virustotal-analysis"
                )
            ) {
                startVirusTotalAnalysis();
            }

            if (
                event.target.closest(
                    "#refresh-virustotal-status"
                )
            ) {
                pollStatusSafely();
                pollEventsSafely();
            }

            if (
                event.target.closest(
                    "#pause-virustotal-analysis"
                )
            ) {
                pauseVirusTotalAnalysis();
            }

            if (
                event.target.closest(
                    "#resume-virustotal-analysis"
                )
            ) {
                resumeVirusTotalAnalysis();
            }

            if (
                event.target.closest(
                    "#cancel-virustotal-analysis"
                )
            ) {
                cancelVirusTotalAnalysis();
            }

            if (
                event.target.closest(
                    "#retry-virustotal-errors"
                )
            ) {
                retryVirusTotalErrors();
            }

            if (
                event.target.closest(
                    "#clear-console-view"
                )
            ) {
                resetConsole();
            }
        }
    );

    window.addEventListener(
        "hashchange",
        synchronizePollingWithRoute
    );

    document.addEventListener(
        "iocplatform:view-loaded",
        synchronizePollingWithRoute
    );

    window.addEventListener(
        "beforeunload",
        stopPolling
    );

    synchronizePollingWithRoute();
}


configureControls();

console.log(
    "Enrichment Control cargado correctamente."
);
