import {
    getStats,
    getIOCs,
    getIOCDetail,
    getIOCExportURL
} from "./api.js";


const state = {
    page: 1,
    pageSize: 25,
    totalPages: 0,
    total: 0
};


function getElement(id) {
    return document.getElementById(id);
}


function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function formatDate(value) {
    if (!value) {
        return "-";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return value;
    }

    return date.toLocaleString("es-MX");
}


function getFilters(includePagination = true) {
    const filters = {
        search: getElement("ioc-search")?.value.trim(),
        tipo: getElement("ioc-tipo")?.value,
        estado: getElement("ioc-estado")?.value,
        fuente: getElement("ioc-fuente")?.value.trim(),
        campaign: getElement("ioc-campaign")?.value.trim(),
        malware_family:
            getElement("ioc-malware-family")?.value.trim(),
        date_from: getElement("ioc-date-from")?.value,
        date_to: getElement("ioc-date-to")?.value
    };

    if (includePagination) {
        filters.page = state.page;
        filters.page_size = state.pageSize;
    }

    return filters;
}


function renderIOCStatus(status) {
    const normalized = String(
        status ?? "sin estado"
    )
        .toLowerCase()
        .replaceAll(" ", "-");

    return `
        <span class="status-badge status-${escapeHTML(normalized)}">
            ${escapeHTML(status ?? "Sin estado")}
        </span>
    `;
}


function renderIOCs(items) {
    const table = getElement("tabla");

    if (!table) {
        return;
    }

    table.innerHTML = "";

    if (!Array.isArray(items) || !items.length) {
        table.innerHTML = `
            <tr>
                <td colspan="10" class="empty-state">
                    No se encontraron IOC con los filtros
                    seleccionados.
                </td>
            </tr>
        `;

        return;
    }

    const rows = items.map((ioc) => `
        <tr data-ioc-id="${escapeHTML(ioc.id)}">
            <td>${escapeHTML(ioc.tipo ?? "-")}</td>

            <td class="ioc-value">
                ${escapeHTML(ioc.valor ?? "-")}
            </td>

            <td>
                ${escapeHTML(
                    ioc.campaign ?? "Sin campaña"
                )}
            </td>

            <td>
                ${escapeHTML(
                    ioc.malware_family ??
                    "No identificado"
                )}
            </td>

            <td>
                ${renderIOCStatus(ioc.vt_estado)}
            </td>

            <td>
                ${escapeHTML(ioc.vt_score ?? 0)}
            </td>

            <td>
                ${escapeHTML(
                    ioc.vt_malicious ?? 0
                )}
            </td>

            <td>
                ${escapeHTML(
                    ioc.vt_suspicious ?? 0
                )}
            </td>

            <td>
                ${escapeHTML(ioc.fuente ?? "-")}
            </td>

            <td>
                ${escapeHTML(
                    formatDate(ioc.ultima_consulta)
                )}
            </td>
        </tr>
    `);

    table.innerHTML = rows.join("");
}


function renderPagination(pagination) {
    if (!pagination) {
        return;
    }

    state.total = pagination.total ?? 0;
    state.totalPages = pagination.total_pages ?? 0;

    const firstItem =
        pagination.total === 0
            ? 0
            : (
                (pagination.page - 1) *
                pagination.page_size
            ) + 1;

    const lastItem = Math.min(
        pagination.page * pagination.page_size,
        pagination.total
    );

    const paginationInfo =
        getElement("ioc-pagination-info");

    if (paginationInfo) {
        paginationInfo.textContent =
            `Mostrando ${firstItem}-${lastItem} de ` +
            `${pagination.total} IOC`;
    }

    const pageNumber =
        getElement("ioc-page-number");

    if (pageNumber) {
        pageNumber.textContent =
            pagination.total_pages > 0
                ? (
                    `Página ${pagination.page} de ` +
                    `${pagination.total_pages}`
                )
                : "Página 0 de 0";
    }

    const previousButton =
        getElement("pagina-anterior");

    if (previousButton) {
        previousButton.disabled =
            !pagination.has_previous;
    }

    const nextButton =
        getElement("pagina-siguiente");

    if (nextButton) {
        nextButton.disabled =
            !pagination.has_next;
    }
}


function showIOCError(message) {
    const errorBox = getElement("ioc-error");

    if (!errorBox) {
        return;
    }

    errorBox.textContent = message;
    errorBox.hidden = false;
}


function hideIOCError() {
    const errorBox = getElement("ioc-error");

    if (!errorBox) {
        return;
    }

    errorBox.textContent = "";
    errorBox.hidden = true;
}


async function cargarStats() {
    const stats = await getStats();

    const total = getElement("total");
    const maliciosos = getElement("maliciosos");
    const sospechosos = getElement("sospechosos");
    const limpios = getElement("limpios");
    const pendientes = getElement("pendientes");
    const errores = getElement("errores");

    if (total) {
        total.textContent = stats.total ?? 0;
    }

    if (maliciosos) {
        maliciosos.textContent =
            stats.maliciosos ?? 0;
    }

    if (sospechosos) {
        sospechosos.textContent =
            stats.sospechosos ?? 0;
    }

    if (limpios) {
        limpios.textContent =
            stats.limpios ?? 0;
    }

    if (pendientes) {
        pendientes.textContent =
            stats.pendientes ?? 0;
    }

    if (errores) {
        errores.textContent =
            stats.errores ?? 0;
    }
}


export async function cargarIOCs() {
    try {
        hideIOCError();

        const response = await getIOCs(
            getFilters(true)
        );

        renderIOCs(response.items ?? []);
        renderPagination(
            response.pagination ?? {
                page: 1,
                page_size: state.pageSize,
                total: 0,
                total_pages: 0,
                has_previous: false,
                has_next: false
            }
        );

    } catch (error) {
        console.error(error);

        showIOCError(
            "No fue posible obtener los IOC."
        );
    }
}


function limpiarFiltros() {
    const fields = [
        "ioc-search",
        "ioc-tipo",
        "ioc-estado",
        "ioc-fuente",
        "ioc-campaign",
        "ioc-malware-family",
        "ioc-date-from",
        "ioc-date-to"
    ];

    for (const fieldId of fields) {
        const field = getElement(fieldId);

        if (field) {
            field.value = "";
        }
    }

    const pageSize =
        getElement("ioc-page-size");

    if (pageSize) {
        pageSize.value = "25";
    }

    state.page = 1;
    state.pageSize = 25;

    cargarIOCs();
}


function exportarIOCs() {
    const dateFrom =
        getElement("ioc-date-from")?.value;

    const dateTo =
        getElement("ioc-date-to")?.value;

    if (
        dateFrom &&
        dateTo &&
        dateFrom > dateTo
    ) {
        showIOCError(
            "La fecha inicial no puede ser mayor " +
            "que la fecha final."
        );

        return;
    }

    hideIOCError();

    const url = getIOCExportURL(
        getFilters(false)
    );

    window.location.href = url;
}



function classifyIOC(ioc) {
    if (String(ioc.vt_estado ?? "").toLowerCase() === "error") {
        return {
            label: "Error",
            cssClass: "is-error"
        };
    }

    if (Number(ioc.vt_malicious ?? 0) > 0) {
        return {
            label: "Malicioso",
            cssClass: "is-malicious"
        };
    }

    if (Number(ioc.vt_suspicious ?? 0) > 0) {
        return {
            label: "Sospechoso",
            cssClass: "is-suspicious"
        };
    }

    if (String(ioc.vt_estado ?? "").toLowerCase() === "analizado") {
        return {
            label: "Limpio",
            cssClass: "is-clean"
        };
    }

    return {
        label: ioc.vt_estado ?? "Sin clasificación",
        cssClass: ""
    };
}


function setDetailText(id, value) {
    const target = getElement(id);

    if (target) {
        target.textContent = value ?? "-";
    }
}


function closeIOCDetail() {
    const drawer = getElement("ioc-detail-drawer");
    const backdrop = getElement("ioc-drawer-backdrop");

    drawer?.classList.remove("is-open");
    drawer?.setAttribute("aria-hidden", "true");

    if (backdrop) {
        backdrop.hidden = true;
    }

    document.body.classList.remove("ioc-drawer-open");
}


async function openIOCDetail(iocId) {
    const drawer = getElement("ioc-detail-drawer");
    const backdrop = getElement("ioc-drawer-backdrop");
    const loading = getElement("ioc-detail-loading");
    const content = getElement("ioc-detail-content");
    const errorBox = getElement("ioc-detail-error");

    if (!drawer) {
        return;
    }

    if (backdrop) {
        backdrop.hidden = false;
    }

    drawer.classList.add("is-open");
    drawer.setAttribute("aria-hidden", "false");
    document.body.classList.add("ioc-drawer-open");

    if (loading) {
        loading.hidden = false;
    }

    if (content) {
        content.hidden = true;
    }

    if (errorBox) {
        errorBox.hidden = true;
        errorBox.textContent = "";
    }

    try {
        const ioc = await getIOCDetail(iocId);
        const classification = classifyIOC(ioc);

        setDetailText("ioc-detail-value", ioc.valor);
        setDetailText("ioc-detail-id", ioc.id);
        setDetailText("ioc-detail-type", ioc.tipo);
        setDetailText("ioc-detail-status", ioc.vt_estado);
        setDetailText(
            "ioc-detail-provider",
            ioc.proveedor_reputacion ?? "-"
        );
        setDetailText("ioc-detail-source", ioc.fuente ?? "-");
        setDetailText(
            "ioc-detail-campaign",
            ioc.campaign ?? "Sin campaña"
        );
        setDetailText(
            "ioc-detail-malware",
            ioc.malware_family ?? "No identificado"
        );
        setDetailText(
            "ioc-detail-score",
            ioc.vt_score ?? 0
        );
        setDetailText(
            "ioc-detail-malicious",
            ioc.vt_malicious ?? 0
        );
        setDetailText(
            "ioc-detail-suspicious",
            ioc.vt_suspicious ?? 0
        );
        setDetailText(
            "ioc-detail-harmless",
            ioc.vt_harmless ?? 0
        );
        setDetailText(
            "ioc-detail-undetected",
            ioc.vt_undetected ?? 0
        );
        setDetailText(
            "ioc-detail-created",
            formatDate(ioc.fecha_creacion)
        );
        setDetailText(
            "ioc-detail-updated",
            formatDate(ioc.ultima_consulta)
        );

        const badge = getElement(
            "ioc-detail-classification"
        );

        if (badge) {
            badge.textContent = classification.label;
            badge.className =
                "ioc-detail-classification " +
                classification.cssClass;
        }

        const copyButton = getElement("copy-ioc-value");

        if (copyButton) {
            copyButton.onclick = async () => {
                await navigator.clipboard.writeText(
                    ioc.valor ?? ""
                );

                copyButton.textContent = "Copiado";

                window.setTimeout(() => {
                    copyButton.textContent = "Copiar IOC";
                }, 1400);
            };
        }

        if (content) {
            content.hidden = false;
        }

    } catch (error) {
        console.error(error);

        if (errorBox) {
            errorBox.textContent =
                "No fue posible obtener el detalle del IOC.";
            errorBox.hidden = false;
        }
    } finally {
        if (loading) {
            loading.hidden = true;
        }
    }
}


function configureIOCDetailDrawer() {
    getElement("tabla")
        ?.addEventListener("click", (event) => {
            const row = event.target.closest(
                "tr[data-ioc-id]"
            );

            if (!row) {
                return;
            }

            openIOCDetail(row.dataset.iocId);
        });

    getElement("close-ioc-drawer")
        ?.addEventListener(
            "click",
            closeIOCDetail
        );

    getElement("ioc-drawer-backdrop")
        ?.addEventListener(
            "click",
            closeIOCDetail
        );

    document.addEventListener(
        "keydown",
        (event) => {
            if (event.key === "Escape") {
                closeIOCDetail();
            }
        }
    );
}


export function configurarIOCExplorer() {
    configureIOCDetailDrawer();
    getElement("aplicar-filtros")
        ?.addEventListener("click", () => {
            state.page = 1;

            state.pageSize = Number(
                getElement("ioc-page-size")?.value
                ?? 25
            );

            cargarIOCs();
        });

    getElement("limpiar-filtros")
        ?.addEventListener(
            "click",
            limpiarFiltros
        );

    getElement("pagina-anterior")
        ?.addEventListener("click", () => {
            if (state.page > 1) {
                state.page -= 1;
                cargarIOCs();
            }
        });

    getElement("pagina-siguiente")
        ?.addEventListener("click", () => {
            if (state.page < state.totalPages) {
                state.page += 1;
                cargarIOCs();
            }
        });

    getElement("ioc-page-size")
        ?.addEventListener(
            "change",
            (event) => {
                state.page = 1;
                state.pageSize = Number(
                    event.target.value
                );

                cargarIOCs();
            }
        );

    getElement("exportar-iocs")
        ?.addEventListener(
            "click",
            exportarIOCs
        );

    getElement("ioc-search")
        ?.addEventListener(
            "keydown",
            (event) => {
                if (event.key === "Enter") {
                    state.page = 1;
                    cargarIOCs();
                }
            }
        );

    getElement("ioc-campaign")
        ?.addEventListener(
            "keydown",
            (event) => {
                if (event.key === "Enter") {
                    state.page = 1;
                    cargarIOCs();
                }
            }
        );

    getElement("ioc-malware-family")
        ?.addEventListener(
            "keydown",
            (event) => {
                if (event.key === "Enter") {
                    state.page = 1;
                    cargarIOCs();
                }
            }
        );
}


export async function cargarDashboard() {
    try {
        await Promise.all([
            cargarStats(),
            cargarIOCs()
        ]);
    } catch (error) {
        console.error(error);
    }
}
